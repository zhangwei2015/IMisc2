#!/usr/bin/perl -w
use strict;

die "perl $0 <pvalue><out><*.final>\n" unless(@ARGV==3);

my @pvalues = split /:/,$ARGV[0];

open O, ">$ARGV[1]" or die;

print O "args <- commandArgs(TRUE)\ntrain<-args[1]\ntest<-args[2]\nlibrary(data.table)\nlibrary(randomForest)\nd<-fread(train,header=TRUE,data.table=F)\nt<-fread(test,header=TRUE,data.table=F)\n";
print O "d\$Flag[d\$flag==1]<-\"Disease\"\n";
print O "d\$Flag[d\$flag==0]<-\"Control\"\n";
print O "t\$Flag[t\$flag==1]<-\"Disease\"\n";
print O "t\$Flag[t\$flag==0]<-\"Control\"\n";
print O "d\$Flag<-as.factor(d\$Flag)\n";
print O "t\$Flag<-as.factor(t\$Flag)\n";


my %uniq;
open I, "$ARGV[2]" or die;
while(<I>)
{
	chomp;
	my @line = split;
	for(@pvalues)
	{
		if($line[2] <= $_){
			$uniq{$_}{"$line[0]_uniq"} = 1;
		}
	}
}
close I;


my $cat="t\$flag";
for(@pvalues)
{
	my $p = $_;
	$p =~ s/e-/e/;
	my $flag = "p${p}_num+p${p}_uniq_sum+p${p}_abund_sum+p${p}_p_sum";
	my @tmp = sort keys %{$uniq{$_}};
	my $uniq_all = join "+", @tmp;
	$flag = "$flag+$uniq_all";

	print O "fit.full<-randomForest(formula = Flag ~ $flag, data=d, importance = T,replace=T,proximity=T)\nt\$p$p<-predict(fit.full, newdata=t, type=\"prob\")\n";
	$cat .= ",t\$p$p\[,2\]";	
}
print O "n<-cat($cat,sep=\"\\t\")\nprint(cat(n,\"\\n\"))\n";
