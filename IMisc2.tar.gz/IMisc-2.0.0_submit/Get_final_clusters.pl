#!/usr/bin/perl -w

die "perl $0 <clusters><*.filter>\n" unless(@ARGV==2);

my %final;
open I, "$ARGV[0]" or die;
while(<I>)
{
	chomp;
	$final{$_} = 1;
}
close I;

open I, "$ARGV[1]" or die;
while(<I>)
{
	chomp;
	my @line = split;
	if(exists $final{$line[0]}){
		print "$_\n";
	}
}
close I;
