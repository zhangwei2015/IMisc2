#!/usr/bine/perl -w
use strict;
use Data::Dumper;

die "perl $0 <in.extend.clones><Disease_control_clones_all.gz><ratio_cutoff><cluster_member_cutoff><out>\n" unless(@ARGV==5);

my ($in_cluster_f,$in_all_f,$ratio_cutoff,$cluster_n_cutoff,$out) = @ARGV;
#my $ratio_cutoff = 100;
#my $cluster_n_cutoff = 10;

my $cluster_n = 0;
my $ratio_n = 0;
my $raw_n = 0;

open O, ">$out" or die;
#print Dumper(\%ID_bad);
my %Seq;
open I, "$in_cluster_f" or die;
while(<I>)
{
	chomp;
	my @line = split;
	my $num = $line[2] =~ tr/:/:/;
	if($num >=$cluster_n_cutoff){
		$Seq{$line[1]} = $_;
	}else{
		$cluster_n++;
	}
	$raw_n++;
}
close I;
#print Dumper(\%Seq);
open I, "gzip -dc $in_all_f|" or die;
<I>;
my %New;
while(<I>)
{
	chomp;
	my @line = split;
	if(exists $Seq{$line[0]})
	{
		my $max = 0;
		for(my $i=3;$i<=$line[1]+2;$i++)
		{
			#			print "$Seq{$line[0]}->[0]\t$line[0]\t$line[$i]\t$Seq{$line[0]}->[1]\n";
			#			push @$New{$line[0]}}
			$max = $line[$i] if($max < $line[$i]);
		}
		my $flag = 0;
		for(my $i=3;$i<=$line[1]+2;$i++)
		{
			my $rate = $max/$line[$i];
			$flag++ if($rate >= $ratio_cutoff);
			#			print "$Seq{$line[0]}->[0]\t$line[0]\t$line[$i]\t$Seq{$line[0]}->[1]\t$rate\n";
		}
		if($flag >= $line[1]-1){
			$ratio_n++;
		}else{
			print O "$Seq{$line[0]}\n";
		}
	}
}
close I;
close O;
print "Raw clusters: $raw_n\n";
print "Filter by Memeber: $cluster_n\n";
print "Filter by Ratios: $ratio_n\n";
