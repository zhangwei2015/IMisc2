#!/usr/bin/perl -w
use strict;

die "perl $0 <file.cdr3><name><flag><All.sample.clone.file.gz><All.samples.pvalues.file.gz><out.clones.gz><out.same.pvalue>\n" unless(@ARGV==7);

my ($cdr3_file, $name, $flag_f, $allclone_file, $pvalues_file,$out_clone_file,$out_same_f) = @ARGV;

open I, "gzip -dc $cdr3_file|" or die;
my %cdr3;

while(<I>)
{
	chomp;
	my @line = split;
	$cdr3{$line[0]} = $line[2];
}
close I;

my $flag = $flag_f;
open I, "gzip -dc $allclone_file|" or die;
open O, "|gzip >$out_clone_file";
open S, ">$out_same_f" or die;
my %same;

my $fir = <I>;
print O "$fir";
while(<I>)
{
	chomp;
	my @line = split;
	my $new = $_;
	if(exists $cdr3{$line[0]})# exists the CDR3 in the file
	{
		my @N =@line[0,1,2];
		if($flag==1)# SLE CDR3
		{
			$N[1]--;
			for(my $i=3; $i<= $line[1]+2; $i++){
				if($line[$i] == $cdr3{$line[0]}){
					if($i<$line[1]+2){
						for(my $j=$i+1 ; $j<= $line[1]+2 ; $j++){
							push @N, $line[$j];
						}
					}
					last;
				}else{
					push @N, $line[$i];
				}
			}
			for(my $i=3+$line[1]; $i<= $line[1]+2+$line[2]; $i++){
				push @N, $line[$i];
			}
		}
		elsif($flag==0)
		{
			$N[2]--;
			for(my $i=3; $i<= $line[1]+2; $i++){
				push @N, $line[$i];
			}
			for(my $i=3+$line[1]; $i<= $line[1]+2+$line[2]; $i++){
				if($line[$i] == $cdr3{$line[0]}){
					if($i<$line[1]+2+$line[2]){
						for(my $j=$i+1 ; $j<= $line[1]+2+$line[2] ; $j++){
							push @N, $line[$j];
						}
					}
					last;
				}else{
					push @N, $line[$i];
				}

			}
		}
		
		next if($N[1] == 0 && $N[2]== 0);# don't exist the CDR3 sequence
		$new = join "\t" , @N;
		print O "$new\n";
	}
	else # the line record is not changed
	{
#		print S "$new\n";
		$same{$line[0]} = 1;		
	}

}
close I;

open I, "gzip -dc $pvalues_file|" or die;
<I>;
while(<I>)
{
	chomp;
	my @line = split;
	if(exists $same{$line[0]}){
		print S "$_\n";
	}
}
close I;
close O;
close S;
