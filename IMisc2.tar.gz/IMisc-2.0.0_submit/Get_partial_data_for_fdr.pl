#!/usr/bin/perl -w
use strict;

die "perl $0 <in.gz><pvalues><out>\n" unless(@ARGV==3);

my @pvalues = split /:/,$ARGV[1];

open O, ">$ARGV[2]" or die;
open I, "gzip -dc $ARGV[0]|" or die;
my $fir = <I>;
print "pvalue\tfdr\n";
my %All;
my %Pvalue_num;
while(<I>)
{
	chomp;
	my @line = split;
	my $n = int log($line[7])/log(10);
	if(exists $All{$n}){
		$All{$n} .= ":$line[7]+$line[8]";
	}else{
		$All{$n} = "$line[7]+$line[8]";
	}
	for(@pvalues){
		if($line[7]<=$_){
			$Pvalue_num{$_}->[0]++ if($line[9] eq "Inf" || $line[9] >1);
			$Pvalue_num{$_}->[1]++ if($line[9] <= 1);
		}
	}	

}
close I;

for(keys %All)
{
	my @P = split /:/, $All{$_};
	my $max = $#P;
	$max = 200 if($max >200);
	for(my $i=0 ; $i<$max; $i++){
		my ($t1, $t2) = split /\+/,$P[$i];
		print "$t1\t$t2\n";
	}
}

print O "pvalue\tnum\tflag\n";
for(sort {$a<=>$b} keys %Pvalue_num)
{
	$Pvalue_num{$_}->[0] = 0 if(!defined($Pvalue_num{$_}->[0]));
	$Pvalue_num{$_}->[1] = 0 if(!defined($Pvalue_num{$_}->[1]));
	print O "$_\t$Pvalue_num{$_}->[0]\tRR>1\n";
	print O "$_\t$Pvalue_num{$_}->[1]\tRR<=1\n";
}
close O;
