#!/usr/bin/perl -w
use strict;
use Data::Dumper;

die "perl $0 <fdr.file.gz> <disease.file.list><cutoff><disease.cutoff><control.cutoff><vj_flag>" unless(@ARGV==6);
my ($in_file, $list_f, $cutoff, $cutoff_d_s, $cutoff_c_s,$vj_flag) = @ARGV;

my $Levenshtein_distance = 1;

my %Public;
my %New;
my %Extend_all;

#  restore the identified specific clones
open I, "gzip -dc $in_file|" or die;
<I>;
while(<I>)
{
        chomp;
        my @line = split;
        if($line[1] >=$cutoff_d_s || $line[2] >=$cutoff_c_s)
        {
                my $RR = "Inf";
                if($line[5]){
                        $RR = ($line[3]/($line[3]+$line[4]))/($line[5]/($line[5]+$line[6]));
                }
                if($RR eq "Inf" || $RR > 1){
                      if($line[7] <= $cutoff){
			      $Public{$line[0]} = 1;
			      push @{$Extend_all{$line[0]}},$line[0];
			      $New{$line[0]}{$line[0]} = 1;
		      }
                }

        }
}
close I;


# building all possible extended clone by Levenshtein_distance = 1
my@AA_20=("G","A","V","L","I","P","F","Y","W","S","T","C","M","N","Q","D","E","K","R","H");
for my $c (keys %Public)
{
	# 1. consider 1 mismatch
# 	2. consider 1 deletion
	my @Base = split //,$c;
        if($vj_flag == 1){
                @Base = ();
                my @tmp = split /_/,$c;
                @Base = split //,$tmp[0];
        }

	for(my $i=0; $i<=$#Base; $i++){
		for(@AA_20){
			if($Base[$i] ne $_)
			{
				my $new = $c;	
				substr($new,$i,1) = $_; # mismatch
				push @{$Extend_all{$new}}, $c;
			}
			my $add_1;
			if($i==0){
				$add_1 = "$_$c";
				push @{$Extend_all{$add_1}}, $c;# addition
			}
			$add_1 = $c;
			substr($add_1,$i,1) = "$Base[$i]$_"; # addition
#				print "$add_1\n";
			push @{$Extend_all{$add_1}}, $c; # addtion/

		}
		my $dele_1 = $c;
		substr($dele_1, $i, 1) = ""; # deletion
		push @{$Extend_all{$dele_1}}, $c;
	}
		
}

#print Dumper(\%Extend_all);

# searching more associated clones
open F, "$list_f" or die;
while(<F>)
{
	chomp;
	my @L = split;
	#	next if($L[1] eq $sample_id);
	open I, "gzip -dc $L[0]|" or die;
	while(<I>)
	{
		chomp;
		my @line = split;
		if(exists $Extend_all{$line[0]})
		{
			for (@{$Extend_all{$line[0]}}){
				$New{$_}{$line[0]} = 1;
			}
		}
#		for my $p (keys %Public)
#		{
#			my $flag = &Compare($line[0],$p);
#			if($flag){
#				$New{$p}{$line[0]} = 1;
#			}
#		}
	}
	close I;
}
close F;

# output results
my $num_f = 0;
for my $p(sort keys %New)
{
#	print "$p\t";
	$num_f++;
	my $out = "C$num_f\t$p\t";
	for(sort keys %{$New{$p}})
	{
		$out .= "$_:";
#		print "$_";
	}
	$out =~ s/:$//;
	print "$out\n";
}

=cut
#my $a="ACCAGTGTT";
#my $b="ACCAGGTGTT";
#my $t = &Compare($a,$b);print "$t\n";
# compare two sequence by Levenshtein_distance
sub Compare
{
	my ($s1, $s2) = @_;
	my $flag = 0;
	($s1,$s2) = length($s1)>length($s2)?($s2,$s1):(($s1,$s2));
	my $s1_len = length($s1);
	my $s2_len = length($s2);
	return($flag) if($s1_len+$Levenshtein_distance < $s2_len);# the length of two sequences exceed the cutoff for comparison
	# 1. two sequences with the same length, only consider mismatch
	if($s1_len == $s2_len){
		my $int = int $s1_len/2;
		my ($s11,$s12) = (substr($s1,0,$int),substr($s1,$int));
		my ($s21,$s22) = (substr($s2,0,$int),substr($s2,$int));
		if($s11 eq $s21 && $s12 eq $s22){
			$flag = 1;
		}elsif($s11 ne $s21 && $s12 ne $s22){
			$flag = 0;
		}elsif($s11 eq $s21 && $s12 ne $s22){
			$flag = &Compare2($s12,$s22);
		}elsif($s11 ne $s21 && $s12 eq $s22){
			$flag = &Compare2($s11,$s21);
		}
	}
	# 2. two sequqences with different length, only consider indel 
	else 
	{
		my @s2_a = split //,$s2;
		my $new_s;
		for(my $i=0; $i<=$#s2_a; $i++){
			my @s2_a_1 = @s2_a;
			$s2_a_1[$i] = "";
			$new_s = join "", @s2_a_1;
			if($new_s eq $s1){
				$flag = 1;
				last;
			}
		}
	}
	return($flag);
}

# Compare two sequences by base-to-base
sub Compare2
{
	my ($s1, $s2) = @_;
	my @s1_a = split //,$s1;
	my @s2_a = split //,$s2;
	my $mismatch = 0;
	for(my $i=0; $i<=$#s1_a; $i++){
		$mismatch++ if($s1_a[$i] ne $s2_a[$i]);
		last if($mismatch > $Levenshtein_distance);
	}
	if($mismatch <= $Levenshtein_distance){
		return 1;
	}else{
		return 0;
	}
}

