#!/usr/bin/perl -w
use strict;

die "perl $0 <in><flag><pvalues>\n" unless(@ARGV==3);

open I, "$ARGV[0]" or die;
#my $fir = <I>;
#print "$fir";
my @Pvalues = split /:/,$ARGV[2];


my %loss;
my $num = 0;
while(<I>)
{
	chomp;
	$num++;
	my @line = split;
	for(my $i=1 ; $i<=$#line ; $i++)
	{
		$loss{$i} = 0 if(!exists $loss{$i});
	if($line[0] == 1){
		$line[$i] = 1e-2 if($line[$i]==0 || $line[$i]<1e-2);
		$loss{$i} = $loss{$i} + log($line[$i]);
	}else{
		$line[$i] = 1-1e-2 if($line[$i]==1 || $line[$i] > 0.99);
		$loss{$i} = $loss{$i} + log(1-$line[$i]);
	}
	}
}
close I;

#print "loss";
for(sort {$a<=>$b} keys %loss)
{
	my $L = -$loss{$_}/$num;
	print "$Pvalues[$_-1]\t$L\t$ARGV[1]\n";
}
#print "\n";
