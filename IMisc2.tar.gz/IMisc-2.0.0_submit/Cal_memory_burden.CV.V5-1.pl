#!/usr/bin/perl -w
use strict;
use File::Basename;

#die "perl $0 <pvalue-cutoff>\n" unless(@ARGV==1);
#  modify:
# memory_burden = x/(number of sample)
#

die "perl $0 <specific.file><raw.recal.gz><in.disease.list><in.control.list><outdir><topn><name>\n" unless(@ARGV==7);



my ($in_file, $raw_f,$in_d_list, $in_c_list,$outdir,$top_num,$name) = @ARGV;


# read the file containing cloen's sample support
my %sample_support;
open I, "gzip -dc $raw_f|" or die;
<I>;
while(<I>)
{
	chomp;
	my @line = split;
        $line[7] = 1e-50 if($line[7]==0);
        $line[7] = -log($line[7])/log(10);
        $line[7] = sqrt($line[7]);
	$sample_support{$line[0]} = "$line[3]\t$line[5]\t$line[7]";
}
close I;


if($in_file =~ /\.gz$/){
	open I, "gzip -dc $in_file|" or die;
}else{
	open I, "$in_file" or die;
}

my %clone;
#my @cutoff = split /:/,$cutoff_pvalues;
#my @cutoff = ("1e-50","1e-40","1e-30","1e-20","1e-15","1e-14","1e-13","1e-12","1e-11","1e-10","1e-9","1e-8","1e-7","1e-6","1e-5","1e-4","5e-4","1e-3","5e-3","1e-2","5e-2","1e-1","5e-1","1");
#my @cutoff = split /:/, $cutoff_pavlues;

#<I>;
my @group;
while(<I>)
{
	chomp;
	my @line = split;
	my @L = split /:/,$line[3];
	push @group, $line[0];
	for(@L){
		push @{$clone{$_}}, $line[0];
	}
}
close I;

my %burden;
my %burden_s;
my %tot_uniq;


open I, "$in_d_list" or die;
while(<I>)
{
        chomp;
	my @F = split;
	my $id = $F[0];
	my $raw = "$F[1]\t1";
	my $tot_abund_top = 0;

	open C, "gzip -dc $id|" or die;
	while(<C>)
	{
		chomp;
		my @line = split;
		last if($. > $top_num);
		$tot_uniq{$raw}++;
		$tot_abund_top += $line[2];
	}
	close C;
	open C, "gzip -dc $id|" or die;
	while(<C>)
	{
		chomp;
		my @line = split;
		last if($. > $top_num);
		if(exists $clone{$line[0]}){
			my ($n1, $n2, $n3) = split /\t/,$sample_support{$line[0]};
			$line[2] = $line[2]/$tot_abund_top*100;
			my $r = log(1e6*$line[2]+1)/log(2);
			my $score = $r*$n3;

			for(@{$clone{$line[0]}}){
				$burden{$raw}{$_}->[0]++;
				$burden{$raw}{$_}->[1] += $r;
				$burden{$raw}{$_}->[2] += $n3;
				$burden{$raw}{$_}->[3] += $score;
			}
                        $burden_s{$raw}->[0]++;
                        $burden_s{$raw}->[1] += $r;
                        $burden_s{$raw}->[2] += $n3;
                        $burden_s{$raw}->[3] += $score;			
		}		

	}
	close C;
}
close I;
open I, "$in_c_list" or die;
while(<I>)
{
	chomp;
	my @F = split;
	my $id = $F[0];
	my $raw = "$F[1]\t0";
        my $tot_abund_top = 0;
	
	open C, "gzip -dc $id|" or die;
        while(<C>)
        {
                chomp;
                my @line = split;
		last if($. > $top_num);
                $tot_uniq{$raw}++;
		$tot_abund_top += $line[2];
	}
	close C;
	open C, "gzip -dc $id|" or die;
	while(<C>)
	{
		chomp;
		my @line = split;
		last if($. > $top_num);
                if(exists $clone{$line[0]}){
			my ($n1, $n2, $n3) = split /\t/,$sample_support{$line[0]};
                        $line[2] = $line[2]/$tot_abund_top*100;
			my $r = log(1e6*$line[2]+1)/log(2);
			my $score = $r*$n3;
			
			for(@{$clone{$line[0]}}){
                                $burden{$raw}{$_}->[0]++;
                                $burden{$raw}{$_}->[1] += $r;
				$burden{$raw}{$_}->[2] += $n3;
				$burden{$raw}{$_}->[3] += $score;
                        }
                        $burden_s{$raw}->[0]++;
                        $burden_s{$raw}->[1] += $r;
                        $burden_s{$raw}->[2] += $n3;
                        $burden_s{$raw}->[3] += $score;
                }
        
	}
        close C;

}
close I;

#print "sample flag uniq_ratio sum_freq\n";

	open O, ">$outdir/$name.memory.burden.training" or die;
	open T, ">$outdir/$name.memory.burden.testing" or die;
	#	print O "sample flag uniq_ratio sum_freq\n";

	print O "sample\tflag\tnum\tuniq_sum\tabund_sum\tp_sum\tscore_sum";
	print T "sample\tflag\tnum\tuniq_sum\tabund_sum\tp_sum\tscore_sum";
	for(@group){
		print O "\t${_}_uniq\t${_}_abund\t${_}_p\t${_}_score";
		print T "\t${_}_uniq\t${_}_abund\t${_}_p\t${_}_score";
	}
	print O "\n";
	print T "\n";


	for my $s(keys %tot_uniq)
	{
		$burden_s{$s} = [0,0,0,0] if(!exists $burden_s{$s});
		my $c_n = scalar(keys %{$burden{$s}});
                my $uniq_sum = $burden_s{$s}->[0]/$tot_uniq{$s}*100;
		
		my $name_tmp = (split /\s+/,$s)[0];
		if($name_tmp eq $name){
			print T "$s\t$c_n\t$uniq_sum\t$burden_s{$s}->[1]\t$burden_s{$s}->[2]\t$burden_s{$s}->[3]";
		}else{
			print O "$s\t$c_n\t$uniq_sum\t$burden_s{$s}->[1]\t$burden_s{$s}->[2]\t$burden_s{$s}->[3]";
		}

		for my $c(@group)
		{
			$burden{$s}{$c} = [0,0,0,0] if(!exists $burden{$s}{$c});
			my $ratio = ($burden{$s}{$c}->[0])/($tot_uniq{$s})*100;
			my $sum_freq = $burden{$s}{$c}->[1];
			if($name_tmp eq $name){
				print T "\t$ratio\t$sum_freq\t$burden{$s}{$c}->[2]\t$burden{$s}{$c}->[3]";
#				print T "\t$ratio\t$sum_freq";
			}else{
				print O "\t$ratio\t$sum_freq\t$burden{$s}{$c}->[2]\t$burden{$s}{$c}->[3]";
			}
		}
		if($name_tmp eq $name){
			print T "\n";
		}else{
			print O "\n";
		}
		
	}
	close O;
	close T;

