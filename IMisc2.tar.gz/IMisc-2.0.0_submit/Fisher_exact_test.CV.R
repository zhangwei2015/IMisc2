#library(data.table)
args<-commandArgs(TRUE)
infile<-args[1]
out<-args[2]

#rt<-read.table(gzfile(infile),header=T,nrows=1000)
rt<-read.table(gzfile(infile),header=T)

# set a new func and use this func at each line of rt dataframe to get the fisher test for a single cdr3 aa
p<-NULL
fisher_test<-function(x){
	mat<-matrix(x,nrow=2)
	f_t<-fisher.test(mat,alternative="two.sided")$p.value
	p<-c(p,f_t)
}
# foreach row of df,use the self-defined func to get the p value
p_value<-apply(rt[,4:7],1,fisher_test)
names(p_value)<-"p_value"
# add the p_value behind the last col of rt
rt<-cbind(rt,p_value)

write.table(rt,file=out,quote=F,row.names=F,col.names=T)
