#!/usr/bin/perl -w 
use strict;
#
#  p = log(1000*f+1,base=2)
#  Correct_support_sample = (Raw+sum{p})/(Raw_total+sum{p})*Raw_total
#  

die "perl $0 <in.file.gz><disease.num><control.num><out.gz>\n" unless(@ARGV==4);

my ($in_f,$d_num, $c_num, $out) = @ARGV;

open I, "gzip -dc $in_f|" or die;
<I>;
open O, "|gzip >$out" or die;
print O "Clone\traw_disease\traw_control\tdisease_c_y\tdisease_c_n\tControl_c_y\tControl_c_n\n";

my $sle_all = $d_num;
my $con_all = $c_num;
while(<I>)
{
	chomp;
	my @line = split;
	my ($new_sle,$new_con) = (0,0);
	my $i = 3;
	my ($sle_1,$sle_2) = ($line[1],$sle_all);
	for(;$i<=$line[1]+2;$i++){
		$sle_1 = $sle_1 +log(10*$line[$i]+1)/log(2);
		$sle_2 = $sle_2 +log(10*$line[$i]+1)/log(2);
	}
	$new_sle = $sle_1/$sle_2*$sle_all;
	$new_sle = sprintf("%0.f",$new_sle);

	my ($con_1,$con_2) = ($line[2],$con_all);
	for(my $j=$i;$j<=$#line;$j++){
		$con_1 = $con_1 +log(10*$line[$j]+1)/log(2);
		$con_2 = $con_2 +log(10*$line[$j]+1)/log(2);
	}
	$new_con = $con_1/$con_2*$con_all;
	$new_con = sprintf("%0.f",$new_con);

	print O "$line[0]\t$line[1]\t$line[2]\t$new_sle\t",$sle_all-$new_sle,"\t$new_con\t",$con_all-$new_con,"\n";
}
close I;
