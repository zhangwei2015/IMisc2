require(ggplot2)
library(gridExtra)
library(grid)

args<-commandArgs(TRUE)
	infile1<-args[1]
	infile2<-args[2]
	out<-args[3]

d<-read.table(infile1,header=TRUE)
#d<-read.table("t.out",header=TRUE)
pdf(out,width=9,height=7)
vplayout <- function(x, y) viewport(layout.pos.row = x, layout.pos.col = y)

g0<-ggplot(d,aes(x=pvalue , y=AUC,col=flag))+geom_point(size=3)+geom_line()+theme_bw()+scale_x_log10()+annotation_logticks()+theme(legend.position=c(0.5,0.5), legend.justification=c(0.5,0.5))
g1<-ggplot(d,aes(x=pvalue , y=accuracy,col=flag))+geom_point(size=3)+geom_line()+theme_bw()+scale_x_log10()+annotation_logticks()+theme(legend.position=c(0.5,0.5), legend.justification=c(0.5,0.5))

d<-read.table(infile2,header=TRUE)
g2<-ggplot(d,aes(x=pvalue , y=loss,col=flag))+geom_point(size=3)+geom_line()+theme_bw()+scale_x_log10()+annotation_logticks()+theme(legend.position=c(0.5,0.5), legend.justification=c(0.5,0.5))

grid.newpage()
pushViewport(viewport(layout = grid.layout(3,1)))
print(g0, vp = vplayout(1,1:1))
print(g1, vp = vplayout(2,1:1))
print(g2, vp = vplayout(3,1:1))

