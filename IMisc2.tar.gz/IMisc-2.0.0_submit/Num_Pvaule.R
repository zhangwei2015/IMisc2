require(ggplot2)
library(gridExtra)
library(grid)

args<-commandArgs(TRUE)
infile<-args[1]
out<-args[2]

d<-read.table(infile,header=TRUE)
pdf(out,width=9,height=6)
vplayout <- function(x, y) viewport(layout.pos.row = x, layout.pos.col = y)

#g0<-ggplot(d,aes(x=pvalue , y=fdr))+geom_point(size=1)+theme_bw()+scale_x_log10(limits=c(1e-20,1))+scale_y_log10(limits=c(1e-20,1))+theme(axis.text.x = element_text(angle=30, hjust=1, vjust=1))+annotation_logticks()+theme(legend.position=c(0,1), legend.justification=c(0,1))
g0<-ggplot(d,aes(x=as.factor(pvalue) , y=num, fill=flag))+geom_bar(stat="identity",position="dodge")+theme_bw()+theme(axis.text.x = element_text(angle=30, hjust=1, vjust=1))+theme(legend.position=c(0.1,0.7), legend.justification=c(0.1,0.7))+geom_text(aes(label=num,col=flag), hjust=-0.5,angle=90,position=position_dodge(0.9))+xlab("Pvalue")+ylab("Clone Number")

#grid.arrange(g0,g1,g2,g5,g6,g7, widths=c(1,1,1,1),heights=c(1,1))
grid.newpage()
pushViewport(viewport(layout = grid.layout(1,1)))
print(g0, vp = vplayout(1,1:1))

