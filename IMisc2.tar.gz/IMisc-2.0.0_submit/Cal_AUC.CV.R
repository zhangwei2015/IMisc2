library(pROC)
args <- commandArgs(TRUE)
infile<-args[1]
p<-args[2]
pvalues<-strsplit(p,":")

d<-read.table(infile,header=FALSE)
for(i in 2:ncol(d))
{
	roc1<-roc(d[,1],d[,i],plot=FALSE,percent=TRUE,partial.auc.correct=TRUE,ci=TRUE, boot.n=100, ci.alpha=0.9, stratified=FALSE, auc.polygon=TRUE, max.auc.polygon=TRUE, grid=TRUE)
	accuracy<-coords(roc1,"best", ret="accuracy",best.method="closest.topleft")
	print(cat(pvalues[[1]][i-1],"\t",roc1$ci[2],"\t",roc1$ci[1],"\t",roc1$ci[3],"\t","CV","\t",accuracy$accuracy[1],"\n"))
#	c<-coords(roc1,"best", ret="accuracy",best.method="closest.topleft")
#	print(c)
}
