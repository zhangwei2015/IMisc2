library(data.table)
args <- commandArgs(TRUE)
in_f<-args[1]
#raw<-args[2]
out<-args[2]

d<-fread(in_f,header=T,sep="\t",data.table=F)
#d<-read.table("../Clone_content.allsample.5e-3.c1",header=T)
d1<-subset(d,d$flag==1)
d2<-subset(d,d$flag==0)
N<-names(d)

if(ncol(d)<3){
	q()
}
Id_f<-data.frame()
for(i in 8:ncol(d))
{
	if(i%%4==0)
	{
	
	p<-wilcox.test(d1[,i],d2[,i])
	M1<-mean(d1[,i])
	M2<-mean(d2[,i])
#	print(paste(N[i],M1,M2,p$p.value))
	if(M1>M2 & p$p.value<=0.05){
		n<-strsplit(N[i],split="_")
		#Id_f<-append(Id_f,n[[1]][1])
		Id_f<-rbind(Id_f,n[[1]][1])
	}
	}
}
fwrite(Id_f,file=out,quote=F,sep="\t",row.names=F,col.names=F)

