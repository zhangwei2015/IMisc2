args<-commandArgs(TRUE)
infile<-args[1]
dcufoff<-args[2]
ccutoff<-args[3]
out<-args[4]

dcufoff<-as.numeric(dcufoff)
ccutoff<-as.numeric(ccutoff)


d<-read.table(gzfile(infile),header=TRUE)
d1<-d[which(d$raw_disease>=dcufoff | d$raw_control>=ccutoff),]

#n<-nrow(d1)

fdr<-p.adjust(d1$p_value,method="fdr")

d1$fdr<-fdr


cal_odd_ratio<-function(x)
{
	or<-(x[1]/(x[1]+x[2]))/(x[3]/(x[3]+x[4]))
	return(or)
}

d1$RR<-apply(d1[,4:7],1,cal_odd_ratio)

write.table(d1,file=gzfile(out),col.names=TRUE,quote=FALSE,row.names=FALSE)

