#!/usr/bin/perl -w
use strict;

die "perl $0 <disease.in.list><control.in.list><out.gz>\n" unless(@ARGV==3);

my ($d_in_list,$c_in_list, $out) = @ARGV;

open O, "|gzip >$out" or die;

my %sle;
my %con;

#print "flag\tsample\tshannon\ttop100\thigh_clone\thigh_clone_num\tgini_vj\tPielou\tCR4\tCR2\n";
open I, "$d_in_list" or die;
while(<I>)
{
	chomp;
	my @F = split;
#	my $id = "/ifs1/ST_IM/USER/fulongfei/RA/$_/Result/after_filtering/${_}_CDR3_AA.frequency.clones.gz";
	my $id = $F[0];
	open C, "gzip -dc $id|" or die;
	while(<C>){
		chomp;
		my @line = split;
		if(defined($sle{$line[0]})){
			$sle{$line[0]} .= ":$line[2]";
		}else{
			$sle{$line[0]} = "$line[2]";
		}
	}
	close C;
#	my $id_vj = "/ifs1/ST_IM/USER/fulongfei/Lupus/$_/Result/after_filtering/${_}_VJ_pairing.usage";
#	$list{$_} = [("SLE",$id, $id_vj)];
}
close I;

#open I, "/szhwfs1/ST_HEALTH/Immune_And_Health_Lab/Pan-IR_F14ZQSYJSY1696/zhangwei/Lupus/hc_samples.eff" or die;
open I, "$c_in_list" or die;
while(<I>)
{
	chomp;
	my @F = split;
#	my $id = "/ifs1/ST_IM/USER/fulongfei/Lupus/hc_wb_15y/$_/Result/after_filtering/${_}_CDR3_AA.frequency.clones.gz";
	my $id = $F[0];
	open C, "gzip -dc $id|" or die;
	while(<C>){
		chomp;
		my @line = split;
		if(defined($con{$line[0]})){
			$con{$line[0]} .= ":$line[2]";
		}else{
			$con{$line[0]} = "$line[2]";
		}
	}
	close C;
#	my $id_vj = "/ifs1/ST_IM/USER/fulongfei/Lupus/hc_wb_15y/$_/Result/after_filtering/${_}_VJ_pairing.usage";
#	$list{$_} = [("Healthy",$id, $id_vj)];
}
close I;

print O "Clone\tDisease\tControl\tFreq\n";

for(keys %sle)
{
	my $num1 =$sle{$_}=~tr/:/ /;
	$num1++;
	my $num2 = 0;
	if(exists $con{$_}){
		$num2 = $con{$_}=~tr/:/ /;
		$num2++;
		print O "$_\t$num1\t$num2\t$sle{$_} $con{$_}\n";
	}else{
		print O "$_\t$num1\t$num2\t$sle{$_}\n";
	}
}

for(keys %con)
{
	my $num2 =$con{$_}=~tr/:/ /;
	$num2++;
	if(!exists $sle{$_}){
		print O "$_\t0\t$num2\t$con{$_}\n";
	}
}
close O;
